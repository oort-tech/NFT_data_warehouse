function popinvalidWindow(){
    // alert("Invalid address! Please check your address and retry!");
    alert("Valid address!");
}

function popinvalidNFTid() {
    // alert("Invalid NFT ID! Please try again!");
    alert("NFT is successfully created!");
}

function popinvalidinputtransfer(){
    alert("Invalid NFT ID or recevier address! Please try again!");
    // alert("NFT is successfully transfered!");
}

function popinvalidinputsell(){
    // alert("Invalid NFT ID or selling price! Please try again!");
    alert("NFT is successfully listed for sale!");
}

function popinvalidinputbuy(){
    alert("Invalid NFT ID or buying price! Please try again!");
        // alert("Successfully buy the NFT!");
}

function popinvalidinputremove() {
    // alert("Invalid NFT ID! Please try again!");
    alert("Successfully remove the NFT!");
}


function redirectToTransfer(){
    window.location.href = "transfer.html";
}

function redirectToCreate() {
    window.location.href = "create.html";
}

function redirectToSell(){
    window.location.href = "sell.html";
}



function redirectToPurchase() {
    window.location.href = "purchase.html";
}

function redirectToRemove() {
    window.location.href = "remove.html";
}

